
import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const Logo = ({ size = 'md', className = '' }: LogoProps) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10', 
    lg: 'w-16 h-16'
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        {/* Hexagone extérieur - beige clair */}
        <polygon 
          points="5,50 27.5,90 72.5,90 95,50 72.5,10 27.5,10" 
          fill="#C4A574"
          opacity="0.6"
        />
        {/* Hexagone moyen - caramel */}
        <polygon 
          points="18,50 35,78 65,78 82,50 65,22 35,22" 
          fill="#D4B896"
          opacity="0.8"
        />
        {/* Hexagone intérieur - doré */}
        <polygon 
          points="32,50 42,66 58,66 68,50 58,34 42,34" 
          fill="#E8D4BC"
        />
        {/* Centre blanc */}
        <polygon 
          points="42,50 47,58 53,58 58,50 53,42 47,42" 
          fill="#FFFFFF"
        />
      </svg>
    </div>
  );
};

export default Logo;
