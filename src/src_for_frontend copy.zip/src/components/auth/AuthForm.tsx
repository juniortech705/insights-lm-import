
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const AuthForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  // Redirect to dashboard if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      console.log('User is authenticated, redirecting to dashboard');
      navigate('/', { replace: true });
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        console.log('Attempting sign up for:', email);
        const { error, data } = await supabase.auth.signUp({
          email,
          password,
        });
        
        if (error) throw error;
        
        toast({
          title: "Compte créé !",
          description: "Vérifiez votre email pour confirmer votre inscription.",
        });
      } else {
        console.log('Attempting sign in for:', email);
        
        const { error, data } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        
        if (error) {
          console.error('Sign in error:', error);
          if (error.message.includes('Invalid login credentials')) {
            throw new Error('Email ou mot de passe incorrect. Veuillez vérifier vos identifiants.');
          } else if (error.message.includes('Email not confirmed')) {
            throw new Error('Veuillez confirmer votre email avant de vous connecter.');
          } else {
            throw error;
          }
        }
        
        console.log('Sign in successful:', data.user?.email);
        
        toast({
          title: "Bon retour !",
          description: "Vous êtes maintenant connecté.",
        });
      }
      
    } catch (error: any) {
      console.error('Auth form error:', error);
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{isSignUp ? 'Créer un compte' : 'Connexion'}</CardTitle>
        <CardDescription>
          {isSignUp ? 'Inscrivez-vous pour commencer votre apprentissage' : 'Entrez vos identifiants pour accéder à vos carnets'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Entrez votre email"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Mot de passe</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Entrez votre mot de passe"
              minLength={6}
            />
          </div>
          <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700" disabled={loading}>
            {loading ? 'Chargement...' : (isSignUp ? 'Créer un compte' : 'Se connecter')}
          </Button>
          <p className="text-center text-sm text-gray-600">
            {isSignUp ? 'Déjà un compte ?' : "Pas encore de compte ?"}{' '}
            <button type="button" onClick={() => setIsSignUp(!isSignUp)} className="text-amber-600 hover:underline font-medium">
              {isSignUp ? 'Se connecter' : "S'inscrire"}
            </button>
          </p>
        </form>
      </CardContent>
    </Card>
  );
};

export default AuthForm;
