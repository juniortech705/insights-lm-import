import React from 'react';
import AuthForm from '@/components/auth/AuthForm';
import Logo from '@/components/ui/Logo';
const Auth = () => {
  return <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-amber-50 to-orange-50">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Logo size="lg" />
          </div>
          <h1 className="text-3xl font-bold text-amber-900 mb-2">AkiliLM</h1>
          <p className="text-amber-700">VOTRE ALLIÉ AU QUOTIDIEN</p>
        </div>
        <AuthForm />
      </div>
    </div>;
};
export default Auth;